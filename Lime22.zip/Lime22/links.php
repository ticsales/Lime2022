<?php
//Number of visits per email
$visits=3;


$normallink = array(
 "lobster-app-sehai.ondigitalocean.app",
// "slimere-v-20-exch-office-pau6d.ondigitalocean.app",
// "page.africeii.com",
);